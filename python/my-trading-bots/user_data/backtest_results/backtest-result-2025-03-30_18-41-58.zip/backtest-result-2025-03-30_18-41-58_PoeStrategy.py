# StablecoinArbitrage.py
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import numpy as np
import logging
from datetime import datetime, timedelta
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class PoeStrategy(IStrategy):
    """
    Stablecoin Mean Reversion Strategy.
    
    This strategy takes advantage of price deviations from the 1:1 peg in stablecoin markets,
    trading on the principle that stablecoins typically revert to their peg.
    
    - Buys when a stablecoin is significantly below its peg (undervalued)
    - Sells when it approaches or exceeds its peg (at fair value or overvalued)
    """
    
    # Minimal ROI - we're targeting small but consistent gains
    minimal_roi = {
        "0": 0.0025  # 0.25% profit target - higher than before to ensure profit
    }
    
    # Settings
    timeframe = '1m'
    stoploss = -0.005  # 0.5% stop loss - wider to avoid premature exits
    trailing_stop = True
    trailing_stop_positive = 0.0005  # 0.05%
    trailing_stop_positive_offset = 0.001  # 0.1%
    trailing_only_offset_is_reached = True
    
    process_only_new_candles = True
    startup_candle_count = 200
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    
    # Define major deviation thresholds
    buy_threshold = 0.0025  # Buy when 0.25% below fair value
    sell_threshold = 0.0005  # Sell when 0.05% above entry
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds mean reversion indicators focused on stablecoin price patterns
        """
        # Calculate rolling stats to identify fair value and deviations
        window = 2880  # Approximately 2 days of 1-minute candles
        
        # Calculate rolling averages with different windows
        dataframe['sma_short'] = dataframe['close'].rolling(window=60).mean()  # 1 hour
        dataframe['sma_medium'] = dataframe['close'].rolling(window=720).mean()  # 12 hours
        dataframe['sma_long'] = dataframe['close'].rolling(window=window).mean()  # 2 days
        
        # Set the fair value baseline (theoretical peg value)
        dataframe['fair_value'] = 1.0000
        
        # Calculate price relative to fair value (% deviation from peg)
        dataframe['peg_deviation'] = (dataframe['fair_value'] - dataframe['close']) / dataframe['fair_value']
        
        # Calculate the rolling standard deviation of price (volatility)
        dataframe['volatility'] = dataframe['close'].rolling(window=window).std()
        
        # Calculate rolling correlation between price and volume to detect liquidity events
        dataframe['price_change'] = dataframe['close'].pct_change(periods=1)
        dataframe['corr'] = dataframe['price_change'].rolling(window=60).corr(dataframe['volume'])
        
        # Mark periods of high volume compared to normal
        dataframe['volume_sma'] = dataframe['volume'].rolling(window=window).mean()
        dataframe['volume_ratio'] = dataframe['volume'] / dataframe['volume_sma']
        
        # Mark potential buy zones when price is below fair value
        dataframe['buy_zone'] = (dataframe['peg_deviation'] > self.buy_threshold)
        
        # Calculate streak of price movement to detect strong trends
        dataframe['price_incr'] = np.where(dataframe['close'] > dataframe['close'].shift(1), 1, 0)
        dataframe['price_decr'] = np.where(dataframe['close'] < dataframe['close'].shift(1), 1, 0)
        
        # Detect strong buying/selling pressure with increased volume
        strong_buy = (
            (dataframe['volume_ratio'] > 1.5) & 
            (dataframe['price_change'] < 0) & 
            (dataframe['peg_deviation'] > 0)
        )
        dataframe['strong_buy'] = np.where(strong_buy, 1, 0)
        
        return dataframe
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Buy when stablecoin is significantly below its peg with signs of reversal
        """
        pair = metadata['pair']
        
        # Only apply to stablecoin pairs
        if 'USDT' in pair and ('USDC' in pair or 'FDUSD' in pair):
            conditions = [
                # Price significantly below peg (undervalued)
                dataframe['buy_zone'],
                
                # Trading volume is above average (liquidity)
                dataframe['volume_ratio'] > 1.2,
                
                # Volatility is not too extreme
                dataframe['volatility'] < 0.001,
                
                # Price falling has slowed down or begun to reverse
                (dataframe['price_incr'].rolling(window=10).sum() >= 4),
                
                # Avoid buying during weekend low volume periods
                dataframe['volume'] > 0
            ]
            
            dataframe['buy'] = np.where(np.logical_and.reduce(conditions), 1, 0)
        else:
            dataframe['buy'] = 0
            
        return dataframe
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Sell when price reverts close to or above the peg
        """
        pair = metadata['pair']
        
        # Only apply to stablecoin pairs
        if 'USDT' in pair and ('USDC' in pair or 'FDUSD' in pair):
            # Sell conditions
            conditions = [
                # Price is at or above fair value (peg)
                dataframe['peg_deviation'] <= 0,
                
                # Volume is reasonable (not during low volume periods)
                dataframe['volume'] > 0
            ]
            
            dataframe['sell'] = np.where(np.logical_and.reduce(conditions), 1, 0)
        else:
            dataframe['sell'] = 0
            
        return dataframe
    
    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float, 
                           time_in_force: str, current_time: datetime, **kwargs) -> bool:
        """
        Additional checks before entering a trade
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return False
            
        # Get the most recent candle
        current_candle = dataframe.iloc[-1].squeeze()
        
        # Only enter if we're buying at least 0.15% below peg value
        if current_candle['peg_deviation'] < 0.0015:
            return False
        
        # Check for sufficient volume
        if current_candle['volume'] * current_candle['close'] < 50000:
            return False
            
        # Make sure price isn't still rapidly falling
        if dataframe['price_decr'].iloc[-5:].sum() >= 4:
            return False
            
        return True
    
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                   current_profit: float, **kwargs):
        """
        Custom exit conditions
        """
        # Get the dataframe
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return None
            
        # If we've been in the trade for over 2 days, exit
        if current_time - trade.open_date_utc > timedelta(days=2):
            return 'timeout_exit'
        
        # If we're in profit and price seems to be starting a downtrend, exit
        if current_profit > 0.001:  # 0.1% profit
            last_candles = dataframe.iloc[-3:].squeeze()
            if last_candles['price_decr'].sum() >= 2:
                return 'exit_downtrend'
                
        return None
    
    # Disable short positions (not applicable for spot trading)
    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                          proposed_stake: float, min_stake: float, max_stake: float,
                          **kwargs) -> float:
        """
        Adjust stake amount - use full stake for high conviction opportunities
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return proposed_stake
            
        current_candle = dataframe.iloc[-1].squeeze()
        
        # Use full stake for very significant deviations (high conviction trades)
        if current_candle['peg_deviation'] > 0.003:  # 0.3% below peg
            return max_stake
            
        return proposed_stake