# StablecoinScalper.py
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame
import numpy as np
import logging
from datetime import datetime, timedelta
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class StablecoinScalper(IStrategy):
    """
    Stablecoin scalping strategy
    Buys at 1.0002 or lower and sells at 1.0003 or higher for USDC/USDT
    """
    
    # Minimal ROI designed for stablecoin scalping
    minimal_roi = {
        "0": 0.0005,  # 0.05% profit is enough to exit a trade
    }
    
    # Settings
    timeframe = '1m'  # Use 1-minute candles
    stoploss = -0.0015  # 0.15% stop loss in case something goes wrong
    trailing_stop = False
    process_only_new_candles = True
    startup_candle_count = 30
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    
    # THIS WAS THE MISSING METHOD
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds indicators to the dataframe
        """
        # For stablecoin scalping, we don't need fancy indicators
        # But we still need to implement this method
        
        # Let's add some basic price levels for reference
        dataframe['buy_level'] = 1.0002
        dataframe['sell_level'] = 1.0003
        
        return dataframe
    
    # Buy when price is at or below our target
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']
        
        # Only apply to stablecoin pairs
        if 'USDT' in pair and ('USDC' in pair or 'BUSD' in pair or 'TUSD' in pair or 'FDUSD' in pair):
            dataframe['buy'] = np.where(dataframe['close'] <= 1.0002, 1, 0)
        else:
            dataframe['buy'] = 0
            
        return dataframe
    
    # Sell when price is at or above our target
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']
        
        # Only apply to stablecoin pairs
        if 'USDT' in pair and ('USDC' in pair or 'BUSD' in pair or 'TUSD' in pair or 'FDUSD' in pair):
            dataframe['sell'] = np.where(dataframe['close'] >= 1.0003, 1, 0)
        else:
            dataframe['sell'] = 0
            
        return dataframe
    
    # Add some minimal protection - don't open trades if volume is too low
    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float, 
                           time_in_force: str, current_time: datetime, **kwargs) -> bool:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        current_candle = dataframe.iloc[-1].squeeze()
        
        # Make sure there's decent volume (at least $10,000 in last candle)
        if current_candle['volume'] * current_candle['close'] < 10000:
            return False
            
        return True
    
    # Custom exit for timeout - exit if a trade has been open too long
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                   current_profit: float, **kwargs):
        
        # If trade open for more than 2 hours, exit even if we have to take a small loss
        if current_time - trade.open_date_utc > timedelta(hours=2):
            return 'timeout_exit'
            
        return None